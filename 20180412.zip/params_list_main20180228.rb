require 'params_list_conf.rb'
module ParamsList

  #params_list.cgi doesn't show this type's value
  class ParamsList

    #define data
    VERSION_FILE = "/etc/info"
    XML_ITEM_STR_DECLARATION = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
    XML_ITEM_STR_NAMESPACE_DEF = "http://www.canon.com/ns/networkcamera/ParameterList/schema"
    XML_ITEM_STR_NAMESPACE_XSI = "http://www.w3.org/2001/XMLSchema-instance"
    XML_ITEM_STR_PARAMS_LIST_VERSION = "1.0"
    XML_ITEM_STR_HEAD = "parameterList"
    XML_ITEM_STR_GROUP_ROOT = "root"

    #index definition of ParameterDefinition
    KVINDEX_GROUP=1
    KVINDEX_GROUP_LAST=3
    KVINDEX_ID=4
    KVINDEX_MAXNUM=5
    KVINDEX_TYPE=6
    KVINDEX_DEFAULT=7
    KVINDEX_PERMISSION=8
    KVINDEX_DESCRIPTION=9
    KVINDEX_CONTENT_VALUE_FIRST=10
    KVINDEX_CONTENT_NAME_FIRST=11
    KVINDEX_CONTENT_OFFSET=2
    PARAMETER_KV_OFFSET=5
    PARAMETER_MAXNUM=KVINDEX_MAXNUM-PARAMETER_KV_OFFSET
    PARAMETER_TYPE=KVINDEX_TYPE-PARAMETER_KV_OFFSET
    PARAMETER_DESCRIPTION=KVINDEX_DESCRIPTION-PARAMETER_KV_OFFSET
    PARAMETER_PERMISSION=KVINDEX_PERMISSION-PARAMETER_KV_OFFSET
    PARAMETER_CONTENT_VALUE_FIRST=KVINDEX_CONTENT_VALUE_FIRST-PARAMETER_KV_OFFSET
    PARAMETER_CONTENT_NAME_FIRST=KVINDEX_CONTENT_NAME_FIRST-PARAMETER_KV_OFFSET

    #constructor
    def initialize()
      #group list defined in ParameterDefinition
      #Hash {"maxnum"=>xxx, group name=>Hash{group name=>Hash...=>Hash{"parameter"=>{parameter id=>pamameter data}}, }

      #parameter in xml count
      @parameter_count=0

      #max size is changed by csv format
      @kvindex_member_max=0
      @parameter_member_max=0

      @escape_words={"&"=>"&amp;", "<"=>"&lt;", ">"=>"&gt;", '"'=>"&quot;", "'"=>"&apos;"}
      #params_list.cgi doesn't show this type's value
      @hide_value_types=["pass", "hpass", "uaccent", "obuaccent"]
    end

    #escape word for xml format
    def escape(str)
      if(str.empty?)
        return str
      end

      @escape_words.each{ |key, value|
        str=str.gsub(/#{key}/, value)
      }
      return str
    end

    def create_filter(query_string)
      filter = {}
      queries = query_string.split('&')
      queries.each{|query|
        kv = query.split('=')
        next if(kv.length != 2)
        req_filters=kv[1].split(".")
        tmp_filter = filter
        req_filters.each{|req_filter|
          if(!tmp_filter.key?(req_filter))
            tmp_filter[req_filter] = {}
          end
          tmp_filter = tmp_filter[req_filter]
        }
      }
      return filter
      # filter = {"Video"=>{"Stream"=>{"Stream-0"=>{"dc06-0"=>{}}}}, "Camera"=>{"db00"=>{}}}
    end

    #get start tag, elem_name, attribute hash{}
    def get_xml_element_start_tag(elem_name, attrs)
      str_attrs=""
      attrs.each{ |key, value|
        str_attrs+=" #{key}=\"#{value}\""
      }
      attrs=nil
      return "<#{elem_name}#{str_attrs}>\n"
    end

    #get end tag
    def get_xml_element_end_tag(elem_name)
      return "</#{elem_name}>\n"
    end

    #get header
    def get_xml_head_start_tag(schema,env)
      attrs={"version"=>XML_ITEM_STR_PARAMS_LIST_VERSION, "xmlns:xsi"=>XML_ITEM_STR_NAMESPACE_XSI, "xmlns"=>XML_ITEM_STR_NAMESPACE_DEF}
      #get ip and port
      ip=env['HTTP_HOST']
      port=env['SERVER_PORT']
      attrs["xsi:schemaLocation"]=XML_ITEM_STR_NAMESPACE_DEF+" http://#{ip}:#{port}#{schema}"
      resp = get_xml_element_start_tag(XML_ITEM_STR_HEAD, attrs)
      attrs=nil
      env=nil
      return resp
    end

    #get header end tag
    def get_xml_head_end_tag()
      return get_xml_element_end_tag(XML_ITEM_STR_HEAD)
    end

    #get tag related to device version
    def get_device_information()
      version=""
      model=""
      build=""
      resp=""
      model = VB.getparam("ra00")
      File.open(VERSION_FILE){|file|
        file.each_line{|line|
          line.lstrip!
          line.chomp!
          kv=line.split('=')
          if(kv[0] && !kv[0].empty? && kv[1] && !kv[1].empty?)
            if(kv[0]=='MODEL')
              model=kv[1]
            elsif(kv[0]=='VERSION')
              version=kv[1]
            elsif(kv[0]=='BUILD')
              build=kv[1]
            end
          end
          kv=nil
        }
      }
      resp += "<model>#{model}</model>\n"
      resp += "<firmwareVersion>#{version}</firmwareVersion>\n"
      resp += "<firmwareRevision>#{build}</firmwareRevision>\n"
      return resp
    end

    #kv=[{name,maxnum}]
    #set group list, from 1 ParameterDefinition line
    def set_to_group_list(kv,group_list)
      id=kv[KVINDEX_ID][0,4]

      tmp_group_list=group_list
      for index in KVINDEX_GROUP..KVINDEX_GROUP_LAST
        if(kv[index]=="")
          break
        end

        if(!tmp_group_list.key?(kv[index]))
          tmp_group_list[kv[index]]={}
        end
        tmp_group_list=tmp_group_list[kv[index]]
      end

      #if there is no subgroup and size > 1, it is in id group
      if(index==KVINDEX_GROUP+1 and kv[KVINDEX_MAXNUM] != "0")
        if(!tmp_group_list.key?(id))
          tmp_group_list[id]={}
        end
        tmp_group_list=tmp_group_list[id]
      end

      #if data is list, set maxnum
      if(kv[KVINDEX_MAXNUM] != "0")
        tmp_group_list["maxnum"]=kv[KVINDEX_MAXNUM]
      end

      if(!tmp_group_list.key?("parameter"))
        tmp_group_list["parameter"]={}
      end
      if(!tmp_group_list["parameter"].key?(kv[KVINDEX_ID]))
        tmp_group_list["parameter"][kv[KVINDEX_ID]]={}
      end

      tmp_group_list["parameter"][kv[KVINDEX_ID]]["value"]=kv[PARAMETER_KV_OFFSET,@kvindex_member_max]
      if(kv[0]=="-")
        #if change spec to disappear unsupported id, please remove tmp_group_list["parameter"][kv[KVINDEX_ID]] hash
        tmp_group_list["parameter"][kv[KVINDEX_ID]]["enabled"]="no"
      end
      tmp_group_list=nil
      kv=nil
    end

    #organize type, type in ParameterDefinition has "type", "size or range or list"
    def organize_type(type)
      size=nil
      tmp_array=type.split(/[\[\]]/)
      if(1 < tmp_array.length)
        size=tmp_array[1]
      end
      #tagname, want to set string before (), [], <>
      typename=tmp_array[0]
      tmp_array=nil

      range=[]
      tmp_array=type.split(/[(,",",)]/)
      if(2 < tmp_array.length)
        range[0]=tmp_array[1]#min
        range[1]=tmp_array[2]#max
      end

      if(tmp_array[0].length < typename.length)
        #update tag name, case which has []
        typename=tmp_array[0]
      end
      tmp_array=nil

      listsize=nil
      tmp_array=type.split(/[<>]/)
      if(1 < tmp_array.length)
        listsize=tmp_array[1]#min
      end

      if(tmp_array[0].length < typename.length)
        #update tag name, case which has <>
        typename=tmp_array[0]
      end
      tmp_array=nil

      return typename, size, range, listsize
    end

    #Please update this method if you want to manage type
    #convert from type in ParameterDefinition to params_list.cgi format type
    def get_type_from_datatype(datatype)
      case datatype
      #type_camera_parameter
      when "coord", "scope" then
        return "fixed"
      #boolean
      when "boolean" then
        return "int"
      else
        return datatype
      end
    end

    #get information to create tags of type
    def get_xml_element_for_type_tag(type, no_attribute_flag)
      #get type, size, range
      datatype, size, range, listsize=organize_type(type)

      typename=get_type_from_datatype(datatype)
      attributes={}
      if(no_attribute_flag=="")
        if(size!=nil)
          attributes["max"]=size
        end

        if(range.length==2)
          if range[0] == "-"
            attributes["min"]=0
          else
            attributes["min"]=range[0]
          end
          if range[1] == "-"
            attributes["max"]=4294967295
          else
            attributes["max"]=range[1]
          end
        end
      end
      range=nil
      return attributes, typename, listsize
    end

    #get rangEntry tag
    def get_xml_element_range_tag(value, content)
      if(value[0].match(/[0-9]/))
        attributes={"value"=>value}
        tagname="rangeEntry"
      elsif(value.include?("int") and value.include?("(") and value.include?(")"))
        attributes, tagname, listsize=get_xml_element_for_type_tag(value,"")
      else
        attributes, tagname, listsize=get_xml_element_for_type_tag(value,"yes")
        if value == "date"
          attributes["max"]="20311231"
          attributes["min"]="20010101"
        end
        if value == "time"
          attributes["max"]="235959"
          attributes["min"]="000000"
        end
      end
      attributes["content"]=content
      return attributes, tagname
    end

    # dc22 is decided by db91, db92 and db93
    def filter_dc22(id, rangeEntryIndex, rangename, attributes)
      dc22_X = id[5].to_i # dc22_X is stream index
      db93 = VB.getparam("db93").to_i # SencerMode
      flag = 0
      resp = ""
      if dc22_X == 0 and db93 == 0 and rangeEntryIndex >= 1 and rangeEntryIndex <= 2
        flag = 1
      elsif dc22_X == 0 and db93 == 1 and rangeEntryIndex >= 0 and rangeEntryIndex <= 2
        flag = 1
      elsif dc22_X == 1 and db93 == 0 and rangeEntryIndex == 2
        flag = 1
      elsif dc22_X == 1 and db93 == 1 and rangeEntryIndex >= 1 and rangeEntryIndex <= 2
        flag = 1
      elsif dc22_X == 2 and db93 == 0 and rangeEntryIndex >= 6 and rangeEntryIndex <= 12
        flag = 1
      elsif dc22_X == 2 and db93 == 1 and rangeEntryIndex >= 3 and rangeEntryIndex <= 12
        flag = 1
      elsif dc22_X >= 3 and dc22_X <= 6 and rangeEntryIndex >= 8 and rangeEntryIndex <= 15
        flag = 1
      elsif dc22_X == 7 and rangeEntryIndex == 3
        flag = 1
      elsif dc22_X == 8 and rangeEntryIndex == 13
        flag = 1
      end
      if flag.to_i == 1
        resp+=get_xml_element_start_tag(rangename, attributes)
        resp+=get_xml_element_end_tag(rangename)
      end
      return resp
    end

    #get xml tags related to type
    def get_xml_parameter_type(id, parameter)
      hwid = VB.capability("CAP_HWID")

      #set type tag
      resp=get_xml_element_start_tag("type",{})

      #set tag related to type
      attributes, typename, listsize=get_xml_element_for_type_tag(parameter[PARAMETER_TYPE], parameter[PARAMETER_CONTENT_VALUE_FIRST])
      if(listsize!=nil)
        tmp_attributes={"maxnum"=>listsize}
        resp+=get_xml_element_start_tag("list", tmp_attributes)
        tmp_attributes=nil
      end

      resp+=get_xml_element_start_tag(typename, attributes)
      attributes=nil

      # Is parameter type is const ?
      isconst = false
      if typename == "const"
        isconst = true
        value = VB.getparam(id)
      end

      #set range tag
      index=PARAMETER_CONTENT_VALUE_FIRST
      rangeEntryIndex = 0
      while( index < @parameter_member_max and  parameter[index] != "" )
        attributes, rangename=get_xml_element_range_tag(parameter[index], parameter[index+1])

        if isconst == false or (isconst == true and parameter[index].to_i == value.to_i)
          # Operation for dc22
          if id[0,4] == "dc22" and hwid == "101" then
            resp+=filter_dc22(id, rangeEntryIndex, rangename, attributes)
          else
            resp+=get_xml_element_start_tag(rangename, attributes)
            resp+=get_xml_element_end_tag(rangename)
          end
        end
        rangeEntryIndex += 1
        index+=KVINDEX_CONTENT_OFFSET
        attributes=nil
      end

      #end tag related to type
      resp+=get_xml_element_end_tag(typename)

      #end list tag
      if(listsize!=nil)
        resp+=get_xml_element_end_tag("list")
      end

      #end type tag
      resp+=get_xml_element_end_tag("type")
      parameter=nil
      return resp
    end

    #get xml tags related to parameter
    def get_xml_parameter_value(id, attributes, parameter)
      @parameter_count+=1
      resp=get_xml_element_start_tag("parameter", attributes)
      resp+=get_xml_parameter_type(id, parameter)
      resp+=get_xml_element_end_tag("parameter")
      attributes=nil
      parameter=nil
      return resp
    end

    #get xml
    #      listsize=nil"parameter" tag
    def get_xml_parameter(parameters, index, filter)
      resp=""
      parameters.each{|parameter_id,parameter_info|
        parameter=parameter_info["value"]
        attributes={"description"=>parameter[PARAMETER_DESCRIPTION],"permission"=>parameter[PARAMETER_PERMISSION]}

        #check maxnum
        maxnum=parameter[PARAMETER_MAXNUM].to_i #parameter's array num
        datatype, size, range, listsize=organize_type(parameter[PARAMETER_TYPE])
        range=nil
        getflag=(@hide_value_types.find{|item| item==datatype}.to_s=="") # @hide_value_types = ["pass", "hpass", "uaccent", "obuaccent"]
        if(index!=nil)
          attributes["order"]="#{index}"
          id="#{parameter_id}-#{index}"
        else
          id=parameter_id
        end

        #check filter
        if(filter.length == 0 or filter.key?(id))
          #set attributes for parameter tag
          attributes["id"] = id
          if(parameter_info["enabled"]=="no")
            attributes["enabled"]=parameter_info["enabled"]
          end
          if(getflag==true)
            attributes["value"] = VB.getparam(id)
          end
          resp+=get_xml_parameter_value(id, attributes, parameter)
        end
        attributes=nil
        parameter=nil
        parameter_info=nil
      }
      filter=nil
      parameters=nil
      return resp
    end

    #get xml "group" or "parameter" tag
    def get_xml_string_part(val, index, filter)
      resp=""
      #Set next parameter
      val.each{|val_key, val_val|
        #skip maxnum
        next if (val_key == "maxnum")

        #if there is no parameter, this hash has sub group
        if(val_key != "parameter")
          #goto next group tag
          resp+=get_xml_string(val_key, val_val, index, filter)
        else
          resp+=get_xml_parameter(val_val, index, filter)
        end
        val_val=nil
      }
      val=nil
      filter=nil
      return resp
    end

    #get xml root tag, create string by recursive call
    # *get group information from part of group_list
    #  -> get xml string to call get_xml_string_part
    #   -> in get_xml_string_part, get parameter tag to call get_xml_parameter
    #                           or get next group to call get_xml_string
    def get_xml_string(group,val,index,filter)
      resp=""
      maxnum=0
      nextfilter=filter
      if(filter.length != 0)
        if(!filter.key?(group)) # If group does not exist in query of params_list.cgi
          #escape group
          return ""
        else
          nextfilter=filter[group]
        end
      end

      #set attributes
      attributes={"name"=>group}
      if(val.key?("maxnum"))
        maxnum=val["maxnum"].to_i
        attributes["maxnum"]=val["maxnum"]
      end

      # get the start of group tag
      resp+=get_xml_element_start_tag("group", attributes)

      if(maxnum!=0)
        #same sub group => same size
        for list_index in 0..maxnum-1
          groupname="#{group}-#{list_index}"

          #set next filter
          if(nextfilter.length != 0)
            next if(!nextfilter.key?(groupname))
            loop_nextfilter=nextfilter[groupname]
          else
            if filter.key?(group)
              loop_nextfilter=nextfilter
            else
              loop_nextfilter=filter
            end
          end

          #Set group-0, 1, ... tag
          list_attributes={"order"=>"#{list_index}", "name"=>groupname}
          resp+=get_xml_element_start_tag("group", list_attributes)
          list_attributes=nil

          #Set parameter with index
          resp+=get_xml_string_part(val, list_index, loop_nextfilter)

          #Set end tag of group-0, 1, ...
          resp+=get_xml_element_end_tag("group")
        end
      else
        resp+=get_xml_string_part(val,index, nextfilter)
      end

      attributes=nil
      loop_nextfilter=nil
      nextfilter=nil
      filter=nil
      val=nil
      #set end tag
      resp+=get_xml_element_end_tag("group")
      return resp
    end

    # dc06 and dc30 is decided by db91, db92 and db93
    def filter_dc06_dc30(id, count)
      db91 = VB.getparam("db91")
      db92 = VB.getparam("db92")
      db93 = VB.getparam("db93")
      if count == 1 and (db93 != "0" or db91 != "0" or db92 != "0")
        return 1
      elsif count == 2 and (db93 != "0" or db91 != "0" or db92 != "1")
        return 2
      elsif count == 3 and (db93 != "0" or db91 != "1" or db92 != "0")
        return 3
      elsif count == 4 and (db93 != "0" or db91 != "1" or db92 != "1")
        return 4
      elsif count == 5 and (db93 != "1" or db91 != "0" or db92 != "0")
        return 5
      elsif count == 6 and (db93 != "1" or db91 != "0" or db92 != "1")
        return 6
      elsif count == 7 and (db93 != "1" or db91 != "1" or db92 != "0")
        return 7
      elsif count == 8 and (db93 != "1" or db91 != "1" or db92 != "1")
        return 8
      end
      return 0
    end

    # check whether the specified queries contain currently read parameter id
    def check_read_params_by_query_filter(kv, filter)
      groups = filter.keys
      groups.each{|group|
        if group.strip == kv[1].strip
          if filter[group].empty?
            return true
          end
          subgroups1 = filter[group].keys
          subgroups1.each{|subgroup1|
            if subgroup1.strip == kv[2].strip or subgroup1.strip.index(kv[4].strip)
              if filter[group][subgroup1].empty?
                return true
              end
              subgroups2 = filter[group][subgroup1].keys
              subgroups2.each{|subgroup2|
                if subgroup2.strip.index(kv[3].strip) or subgroup2.strip.index(kv[4].strip)
                  if filter[group][subgroup1][subgroup2].empty?
                    return true
                  end
                  ids = filter[group][subgroup1][subgroup2].keys
                  ids.each{|id|
                    if id.strip.index(kv[4].strip) or id.strip.index(kv[4].strip)
                        return true
                    end
                  }
                  return false
                end
              }
              return false
            end
          }
          return false
        end
      }
      return false
    end

    #set group list from ParameterDefinition file
    def set_group_list_from_incfile(file, group_list, filter)

      dc06_count = 0
      dc30_count = 0
      #set base table
      File.open(file){|f|
        f.each_line{ |line|
          #skip 1st line
          line.lstrip!

          #There are all ids in Base definition, so parse only " " and "-"
          next if (!line.start_with?(';') and !line.start_with?('-'))

          #Fail safe check
          kv=line.split(';')

          if filter.length != 0
            read_flag = check_read_params_by_query_filter(kv, filter)
            next if read_flag == false
          end

          # Operation for dc06 and dc30
          id = kv[KVINDEX_ID][0,4]
          next_flag = 0
          if id == "dc06"
            dc06_count += 1
            next_flag = filter_dc06_dc30(id, dc06_count)
          elsif id == "dc30"
            dc30_count += 1
            next_flag = filter_dc06_dc30(id, dc30_count)
          end
          if next_flag.to_i > 0
            next
          end

          if(@kvindex_member_max==0)
            @kvindex_member_max=kv.length
            @parameter_member_max=@kvindex_member_max-PARAMETER_KV_OFFSET
          else
            #skip line
            if(@kvindex_member_max!=kv.length)
              kv=nil
              next
            end
          end

          #get or delete group settings
          set_to_group_list(kv,group_list)
          kv=nil
        }
      }
    end

    #get different file related to HWID
    def get_diff_file()
      hwid=VB.capability("CAP_HWID")
      if(CSV_FILE_TABLE.key?(hwid) )
        return CSV_FILE_TABLE[hwid]
      else
        return nil
      end
    end

    def create_grouplist(filter)
      group_list={}
      set_group_list_from_incfile(CSV_FILE_TABLE["base"], group_list, filter)

      #get diff file
      file=get_diff_file()
      if(file != nil)
        set_group_list_from_incfile(file, group_list, filter)
      end

      return group_list
    end

    #get all xml format string
    def get_xml(env)
      @parameter_count = 0
      @kvindex_member_max = 0
      @parameter_member_max = 0
      group_list = {}
      filter = {}
      #separate query
      if(env.key?("QUERY_STRING"))
        filter = create_filter(env["QUERY_STRING"])
      end
      #create paramslist start tag, model tag, firmwareVersion tag and firmwareRevision tag
      resp = XML_ITEM_STR_DECLARATION
      resp += get_xml_head_start_tag(XML_SCHEMA_PATH, env)
      resp += get_device_information()
      #get csv
      group_list = create_grouplist(filter)
      #create xml root tag
      resp += get_xml_element_start_tag(XML_ITEM_STR_GROUP_ROOT, {})
      group_list.each{|group, val|
        # arg1: group name, arg2: group elements, arg4: query of params_list.cgi
        resp += get_xml_string(group, val, nil, filter)
        GC.start
      }
      if(@parameter_count != 0)
        resp += get_xml_element_end_tag(XML_ITEM_STR_GROUP_ROOT)
      end
      #create paramslist end tag
      resp += get_xml_head_end_tag()
      return resp
    end

    #main
    def call(env)
      result = ""
      mutex_result = VB.trylock_paramslist()
      if(mutex_result == true)
        result = get_xml(env)
        VB.unlock_paramslist()
      else
        result = "params_list.cgi is running."
      end
      GC.start
      #puts "paramslist: mutex_result #{mutex_result}\n----------\n#{result}"
      # respones
      if mutex_result
        [200, {"content-type" => "text/xml",}, ["#{result}\n"]]
      else
        [503, {"content-type" => "text/plain",}, ["#{result}\n"]]
      end
    end
  end
end
#ParamsList::ParamsList.new().call({})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0&group=Video.Stream.Stream-0.dc07-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00.db00-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00.db00-0.db00-0"})
