require 'params_list_conf.rb'
module ParamsList

  #params_list.cgi doesn't show this type's value
  class ParamsList

    #define data
    VERSION_FILE = "/etc/info"
    XML_ITEM_STR_DECLARATION = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
    XML_ITEM_STR_NAMESPACE_DEF = "http://www.canon.com/ns/networkcamera/ParameterList/schema"
    XML_ITEM_STR_NAMESPACE_XSI = "http://www.w3.org/2001/XMLSchema-instance"
    XML_ITEM_STR_PARAMS_LIST_VERSION = "1.0"
    XML_ITEM_STR_HEAD = "parameterList"
    XML_ITEM_STR_GROUP_ROOT = "root"

    #index definition of ParameterDefinition
    KVINDEX_GROUP=1
    KVINDEX_GROUP_LAST=3
    KVINDEX_ID=4
    KVINDEX_MAXNUM=5
    KVINDEX_TYPE=6
    KVINDEX_PERMISSION=7
    KVINDEX_DESCRIPTION=8
    KVINDEX_CONTENT_VALUE_FIRST=9
    KVINDEX_CONTENT_NAME_FIRST=10
    KVINDEX_CONTENT_OFFSET=2
    PARAMETER_KV_OFFSET=5
    PARAMETER_MAXNUM=KVINDEX_MAXNUM-PARAMETER_KV_OFFSET
    PARAMETER_TYPE=KVINDEX_TYPE-PARAMETER_KV_OFFSET
    PARAMETER_DESCRIPTION=KVINDEX_DESCRIPTION-PARAMETER_KV_OFFSET
    PARAMETER_PERMISSION=KVINDEX_PERMISSION-PARAMETER_KV_OFFSET
    PARAMETER_CONTENT_VALUE_FIRST=KVINDEX_CONTENT_VALUE_FIRST-PARAMETER_KV_OFFSET
    PARAMETER_CONTENT_NAME_FIRST=KVINDEX_CONTENT_NAME_FIRST-PARAMETER_KV_OFFSET

    #constructor
    def initialize()
      #group list defined in ParameterDefinition
      #Hash {"maxnum"=>xxx, group name=>Hash{group name=>Hash...=>Hash{"parameter"=>{parameter id=>pamameter data}}, }

      #parameter in xml count
      @parameter_count=0

      #max size is changed by csv format
      @kvindex_member_max=0
      @parameter_member_max=0

      @escape_words={"&"=>"&amp;", "<"=>"&lt;", ">"=>"&gt;", '"'=>"&quot;", "'"=>"&apos;"}
      #params_list.cgi doesn't show this type's value
      @hide_value_types=["pass", "hpass", "uaccent", "obuaccent"]
    end

    #escape word for xml format
    def escape(str)
      if(str.empty?)
        return str
      end

      @escape_words.each{ |key, value|
        str=str.gsub(/#{key}/, value)
      }
      return str
    end

    def create_filter(query_string)
      filter = {}
      queries = query_string.split('&')
      queries.each{|query|
        kv = query.split('=')
        next if(kv.length != 2)
        req_filters=kv[1].split(".")
        tmp_filter = filter
        req_filters.each{|req_filter|
          if(!tmp_filter.key?(req_filter))
            tmp_filter[req_filter] = {}
          end
          tmp_filter = tmp_filter[req_filter]
        }
      }
      return filter
      # filter = {"Video"=>{"Stream"=>{"Stream-0"=>{"dc06-0"=>{}}}}, "Camera"=>{"db00"=>{}}}
    end

    #get start tag, elem_name, attribute hash{}
    def get_xml_element_start_tag(elem_name, attrs)
      str_attrs=""
      attrs.each{ |key, value|
        str_attrs+=" #{key}=\"#{value}\""
      }
      attrs=nil
      return "<#{elem_name}#{str_attrs}>\n"
    end

    #get end tag
    def get_xml_element_end_tag(elem_name)
      return "</#{elem_name}>\n"
    end

    #get header
    def get_xml_head_start_tag(schema,env)
      attrs={"version"=>XML_ITEM_STR_PARAMS_LIST_VERSION, "xmlns:xsi"=>XML_ITEM_STR_NAMESPACE_XSI, "xmlns"=>XML_ITEM_STR_NAMESPACE_DEF}
      #get ip and port
      ip=env['HTTP_HOST']
      port=env['SERVER_PORT']
      attrs["xsi:schemaLocation"]=XML_ITEM_STR_NAMESPACE_DEF+" http://#{ip}:#{port}#{schema}"
      resp = get_xml_element_start_tag(XML_ITEM_STR_HEAD, attrs)
      attrs=nil
      env=nil
      return resp
    end

    #get header end tag
    def get_xml_head_end_tag()
      return get_xml_element_end_tag(XML_ITEM_STR_HEAD)
    end

    #get tag related to device version
    def get_device_information()
      version=""
      model=""
      build=""
      resp=""
      model = VB.getparam("ra00")
      File.open(VERSION_FILE){|file|
        file.each_line{|line|
          line.lstrip!
          line.chomp!
          kv=line.split('=')
          if(kv[0] && !kv[0].empty? && kv[1] && !kv[1].empty?)
            if(kv[0]=='MODEL')
              model=kv[1]
            elsif(kv[0]=='VERSION')
              version=kv[1]
            elsif(kv[0]=='BUILD')
              build=kv[1]
            end
          end
          kv=nil
        }
      }
      resp += "<model>#{model}</model>\n"
      resp += "<firmwareVersion>#{version}</firmwareVersion>\n"
      resp += "<firmwareRevision>#{build}</firmwareRevision>\n"
      return resp
    end

    #kv=[{name,maxnum}]
    #set group list, from 1 ParameterDefinition line
    def set_to_group_list(kv,group_list)
      id=kv[KVINDEX_ID][0,4]

      tmp_group_list=group_list
      for index in KVINDEX_GROUP..KVINDEX_GROUP_LAST
        if(kv[index]=="")
          break
        end

        if(!tmp_group_list.key?(kv[index]))
          tmp_group_list[kv[index]]={}
        end
        tmp_group_list=tmp_group_list[kv[index]]
      end

      #if there is no subgroup and size > 1, it is in id group
      if(index==KVINDEX_GROUP+1 and kv[KVINDEX_MAXNUM] != "0")
        if(!tmp_group_list.key?(id))
          tmp_group_list[id]={}
        end
        tmp_group_list=tmp_group_list[id]
      end

      #if data is list, set maxnum
      if(kv[KVINDEX_MAXNUM] != "0")
        tmp_group_list["maxnum"]=kv[KVINDEX_MAXNUM]
      end

      if(!tmp_group_list.key?("parameter"))
        tmp_group_list["parameter"]={}
      end
      if(!tmp_group_list["parameter"].key?(kv[KVINDEX_ID]))
        tmp_group_list["parameter"][kv[KVINDEX_ID]]={}
      end

      tmp_group_list["parameter"][kv[KVINDEX_ID]]["value"]=kv[PARAMETER_KV_OFFSET,@kvindex_member_max]
      if(kv[0]=="-")
        #if change spec to disappear unsupported id, please remove tmp_group_list["parameter"][kv[KVINDEX_ID]] hash
        tmp_group_list["parameter"][kv[KVINDEX_ID]]["enabled"]="no"
      end
      tmp_group_list=nil
      kv=nil
    end

    #organize type, type in ParameterDefinition has "type", "size or range or list"
    def organize_type(type)
      size=nil
      tmp_array=type.split(/[\[\]]/)
      if(1 < tmp_array.length)
        size=tmp_array[1]
      end
      #tagname, want to set string before (), [], <>
      typename=tmp_array[0]
      tmp_array=nil

      range=[]
      tmp_array=type.split(/[(,",",)]/)
      if(2 < tmp_array.length)
        range[0]=tmp_array[1]#min
        range[1]=tmp_array[2]#max
      end

      if(tmp_array[0].length < typename.length)
        #update tag name, case which has []
        typename=tmp_array[0]
      end
      tmp_array=nil

      listsize=nil
      tmp_array=type.split(/[<>]/)
      if(1 < tmp_array.length)
        listsize=tmp_array[1]#min
      end

      if(tmp_array[0].length < typename.length)
        #update tag name, case which has <>
        typename=tmp_array[0]
      end
      tmp_array=nil

      return typename, size, range, listsize
    end

    #Please update this method if you want to manage type
    #convert from type in ParameterDefinition to params_list.cgi format type
    def get_type_from_datatype(datatype)
      case datatype
      #type_camera_parameter
      when "coord", "scope" then
        return "fixed"
      #boolean
      when "boolean" then
        return "int"
      else
        return datatype
      end
    end

    #get information to create tags of type
    def get_xml_element_for_type_tag(type, no_attribute_flag)
      #get type, size, range
      datatype, size, range, listsize=organize_type(type)

      typename=get_type_from_datatype(datatype)
      attributes={}
      if(no_attribute_flag=="")
        if(size!=nil)
          attributes["max"]=size
        end

        if(range.length==2)
          if range[0] == "-"
            attributes["min"]=0
          else
            attributes["min"]=range[0]
          end
          if range[1] == "-"
            attributes["max"]=4294967295
          else
            attributes["max"]=range[1]
          end
        end
      end
      range=nil
      return attributes, typename, listsize
    end

    #get rangEntry tag
    def get_xml_element_range_tag(value, content)
      if(value[0].match(/[0-9]/))
        attributes={"value"=>value}
        tagname="rangeEntry"
      elsif(value.include?("int") and value.include?("(") and value.include?(")"))
        attributes, tagname, listsize=get_xml_element_for_type_tag(value,"")
      else
        attributes, tagname, listsize=get_xml_element_for_type_tag(value,"yes")
        if value == "date"
          attributes["max"]="20311231"
          attributes["min"]="20010101"
        end
        if value == "time"
          attributes["max"]="235959"
          attributes["min"]="000000"
        end
      end
      attributes["content"]=content
      return attributes, tagname
    end

    #get xml tags related to type
    def get_xml_parameter_type(id, parameter)

      #set type tag
      resp=get_xml_element_start_tag("type",{})

      #set tag related to type
      attributes, typename, listsize=get_xml_element_for_type_tag(parameter[PARAMETER_TYPE], parameter[PARAMETER_CONTENT_VALUE_FIRST])
      if(listsize!=nil)
        tmp_attributes={"maxnum"=>listsize}
        resp+=get_xml_element_start_tag("list", tmp_attributes)
        tmp_attributes=nil
      end

      resp+=get_xml_element_start_tag(typename, attributes)
      attributes=nil

      # Is parameter type is const ?
      isconst = false
      if typename == "const"
        isconst = true
        value = VB.getparam(id)
      end

      #set range tag
      index=PARAMETER_CONTENT_VALUE_FIRST
      rangeEntryIndex = 0
      while( index < @parameter_member_max and  parameter[index] != "" )
        attributes, rangename=get_xml_element_range_tag(parameter[index], parameter[index+1])

        if isconst == false or (isconst == true and parameter[index].to_i == value.to_i)
          resp+=get_xml_element_start_tag(rangename, attributes)
          resp+=get_xml_element_end_tag(rangename)
        end
        rangeEntryIndex += 1
        index+=KVINDEX_CONTENT_OFFSET
        attributes=nil
      end

      # filter for dc22
      if id[0,4] == "dc22"
        resp += filter_for_dc22(id)
      end

      #end tag related to type
      resp+=get_xml_element_end_tag(typename)

      #end list tag
      if(listsize!=nil)
        resp+=get_xml_element_end_tag("list")
      end

      #end type tag
      resp+=get_xml_element_end_tag("type")
      parameter=nil
      return resp
    end

    #get xml tags related to parameter
    def get_xml_parameter_value(id, attributes, parameter)
      @parameter_count+=1
      resp=get_xml_element_start_tag("parameter", attributes)
      resp+=get_xml_parameter_type(id, parameter)
      resp+=get_xml_element_end_tag("parameter")
      attributes=nil
      parameter=nil
      return resp
    end

    #get xml
    #      listsize=nil"parameter" tag
    def get_xml_parameter(parameters, index, filter)
      resp=""
      parameters.each{|parameter_id,parameter_info|
        parameter=parameter_info["value"]
        attributes={"description"=>parameter[PARAMETER_DESCRIPTION],"permission"=>parameter[PARAMETER_PERMISSION]}

        #check maxnum
        maxnum=parameter[PARAMETER_MAXNUM].to_i #parameter's array num
        datatype, size, range, listsize=organize_type(parameter[PARAMETER_TYPE])
        range=nil
        getflag=(@hide_value_types.find{|item| item==datatype}.to_s=="") # @hide_value_types = ["pass", "hpass", "uaccent", "obuaccent"]
        if(index!=nil)
          attributes["order"]="#{index}"
          id="#{parameter_id}-#{index}"
        else
          id=parameter_id
        end

        #check filter
        if(filter.length == 0 or filter.key?(id))
          #set attributes for parameter tag
          attributes["id"] = id
          if(parameter_info["enabled"]=="no")
            attributes["enabled"]=parameter_info["enabled"]
          end
          if(getflag==true)
            attributes["value"] = VB.getparam(id)
          end
          resp+=get_xml_parameter_value(id, attributes, parameter)
        end
        attributes=nil
        parameter=nil
        parameter_info=nil
      }
      filter=nil
      parameters=nil
      return resp
    end

    #get xml "group" or "parameter" tag
    def get_xml_string_part(val, index, filter)
      resp=""
      #Set next parameter
      val.each{|val_key, val_val|
        #skip maxnum
        next if (val_key == "maxnum")

        #if there is no parameter, this hash has sub group
        if(val_key != "parameter")
          #goto next group tag
          resp+=get_xml_string(val_key, val_val, index, filter)
        else
          resp+=get_xml_parameter(val_val, index, filter)
        end
        val_val=nil
      }
      val=nil
      filter=nil
      return resp
    end

    #get xml root tag, create string by recursive call
    # *get group information from part of group_list
    #  -> get xml string to call get_xml_string_part
    #   -> in get_xml_string_part, get parameter tag to call get_xml_parameter
    #                           or get next group to call get_xml_string
    def get_xml_string(group, val, index, filter)
      resp=""
      maxnum=0
      nextfilter=filter
      if(filter.length != 0)
        if(!filter.key?(group)) # If group does not exist in query of params_list.cgi
          #escape group
          return ""
        else
          nextfilter=filter[group]
        end
      end

      #set attributes
      attributes={"name"=>group}
      if(val.key?("maxnum"))
        maxnum=val["maxnum"].to_i
        attributes["maxnum"]=val["maxnum"]
      end

      # get the start of group tag
      resp+=get_xml_element_start_tag("group", attributes)

      if(maxnum!=0)
        #same sub group => same size
        for list_index in 0..maxnum-1
          groupname="#{group}-#{list_index}"

          #set next filter
          if(nextfilter.length != 0)
            next if(!nextfilter.key?(groupname))
            loop_nextfilter=nextfilter[groupname]
          else
            if filter.key?(group)
              loop_nextfilter=nextfilter
            else
              loop_nextfilter=filter
            end
          end

          #Set group-0, 1, ... tag
          list_attributes={"order"=>"#{list_index}", "name"=>groupname}
          resp+=get_xml_element_start_tag("group", list_attributes)
          list_attributes=nil

          #Set parameter with index
          resp+=get_xml_string_part(val, list_index, loop_nextfilter)

          #Set end tag of group-0, 1, ...
          resp+=get_xml_element_end_tag("group")
        end
      else
        resp+=get_xml_string_part(val,index, nextfilter)
      end

      attributes=nil
      loop_nextfilter=nil
      nextfilter=nil
      filter=nil
      val=nil
      #set end tag
      resp+=get_xml_element_end_tag("group")
      return resp
    end

    # check whether the specified queries contain currently read parameter id
    def check_read_params_by_query_filter(kv, filter)
      groups = filter.keys
      groups.each{|group|
        if group.strip == kv[1].strip
          if filter[group].empty?
            return true
          end
          subgroups1 = filter[group].keys
          subgroups1.each{|subgroup1|
            if subgroup1.strip == kv[2].strip or subgroup1.strip.index(kv[4].strip)
              if filter[group][subgroup1].empty?
                return true
              end
              subgroups2 = filter[group][subgroup1].keys
              subgroups2.each{|subgroup2|
                if subgroup2.strip.index(kv[3].strip) or subgroup2.strip.index(kv[4].strip)
                  if filter[group][subgroup1][subgroup2].empty?
                    return true
                  end
                  ids = filter[group][subgroup1][subgroup2].keys
                  ids.each{|id|
                    if id.strip.index(kv[4].strip) or id.strip.index(kv[4].strip)
                      return true
                    end
                  }
                  return false
                end
              }
              return false
            end
          }
          return false
        end
      }
      return false
    end

    # filter for ID:dc06
    def filter_for_dc06(kv_array)
      db = VB.getparams("db91-0,db92-0,db93-0")
      if db["db91-0"] == '0' and db["db92-0"] == '0' and db["db93-0"] == '0'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "4"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "6.25 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 8] = "5"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 8] = "12.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 10] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 10] = "25 fps"
      elsif db["db91-0"] == '0' and db["db92-0"] == '0' and db["db93-0"] == '1'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1.04 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "6.25 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "12.5 fps"
      elsif db["db91-0"] == '0' and db["db92-0"] == '1' and db["db93-0"] == '0'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "4"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "6.25 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 8] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 8] = "12.5 fps"
      elsif db["db91-0"] == '0' and db["db92-0"] == '1' and db["db93-0"] == '1'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1.04 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "6.25 fps"
      elsif db["db91-0"] == '1' and db["db92-0"] == '0' and db["db93-0"] == '0'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "3 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "4"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 8] = "5"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 8] = "6 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 10] = "6"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 10] = "10 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 12] = "7"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 12] = "15 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 14] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 14] = "30 fps"
      elsif db["db91-0"] == '1' and db["db92-0"] == '0' and db["db93-0"] == '1'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "3 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "6 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "4"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "7.5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 8] = "5"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 8] = "15 fps"
      elsif db["db91-0"] == '1' and db["db92-0"] == '1' and db["db93-0"] == '0'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "2 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "3 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "4"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 8] = "5"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 8] = "6 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 10] = "6"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 10] = "10 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 12] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 12] = "15 fps"
      elsif db["db91-0"] == '1' and db["db92-0"] == '1' and db["db93-0"] == '1'
        kv_array[KVINDEX_CONTENT_VALUE_FIRST] = "1"
        kv_array[KVINDEX_CONTENT_NAME_FIRST] = "1 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 2] = "2"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 2] = "3 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 4] = "3"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 4] = "5 fps"
        kv_array[KVINDEX_CONTENT_VALUE_FIRST + 6] = "8"
        kv_array[KVINDEX_CONTENT_NAME_FIRST + 6] = "7.5 fps"
      end
    end

    # filter for ID:dc22
    def filter_for_dc22(id)
      resp = ""
      if id == "dc22-0"
        db93 = VB.getparam("db93-0")
        if db93 == '1'
          resp += "<rangeEntry value=\"3296x3296\" content=\"3296x3296\">\n"
          resp += "</rangeEntry>\n"
        end
        resp += "<rangeEntry value=\"1648x1648\" content=\"1648x1648\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"824x824\" content=\"824x824\">\n"
        resp += "</rangeEntry>\n"
      elsif id == "dc22-1" or id == "dc22-2"
        resp += "<rangeEntry value=\"824x824\" content=\"824x824\">\n"
        resp += "</rangeEntry>\n"
      elsif id == "dc22-3"
        db93 = VB.getparam("db93-0")
        if db93 == '1'
          resp += "<rangeEntry value=\"3840x2160\" content=\"3840x2160\">\n"
          resp += "</rangeEntry>\n"
          resp += "<rangeEntry value=\"2560x1440\" content=\"2560x1440\">\n"
          resp += "</rangeEntry>\n"
        end
        resp += "<rangeEntry value=\"1920x1440\" content=\"1920x1440\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"1920x1080\" content=\"1920x1080\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"1280x960\" content=\"1280x960\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"1280x720\" content=\"1280x720\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"960x720\" content=\"960x720\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"960x540\" content=\"960x540\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"640x480\" content=\"640x480\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"640x360\" content=\"640x360\">\n"
        resp += "</rangeEntry>\n"
      elsif id == "dc22-4" or id == "dc22-5" or id == "dc22-6" or id == "dc22-7"
        resp += "<rangeEntry value=\"1280x720\" content=\"1280x720\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"960x720\" content=\"960x720\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"960x540\" content=\"960x540\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"640x480\" content=\"640x480\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"640x360\" content=\"640x360\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"480x360\" content=\"480x360\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"480x270\" content=\"480x270\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"320x240\" content=\"320x240\">\n"
        resp += "</rangeEntry>\n"
        resp += "<rangeEntry value=\"320x180\" content=\"320x180\">\n"
        resp += "</rangeEntry>\n"
      elsif id == "dc22-8"
        resp += "<rangeEntry value=\"480x270\" content=\"480x270\">\n"
        resp += "</rangeEntry>\n"
      end
      return resp
    end

    # filter for ID:dc30
    def filter_for_dc30(kv_array)
      db = VB.getparams("db91-0,db92-0,db93-0")
      if db["db91-0"] == '0' and db["db92-0"] == '0' and db["db93-0"] == '0'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,25.0)"
      elsif db["db91-0"] == '0' and db["db92-0"] == '0' and db["db93-0"] == '1'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,12.5)"
      elsif db["db91-0"] == '0' and db["db92-0"] == '1' and db["db93-0"] == '0'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,12.5)"
      elsif db["db91-0"] == '0' and db["db92-0"] == '1' and db["db93-0"] == '1'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,6.2)"
      elsif db["db91-0"] == '1' and db["db92-0"] == '0' and db["db93-0"] == '0'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,30.0)"
      elsif db["db91-0"] == '1' and db["db92-0"] == '0' and db["db93-0"] == '1'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,15.0)"
      elsif db["db91-0"] == '1' and db["db92-0"] == '1' and db["db93-0"] == '0'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,15.0)"
      elsif db["db91-0"] == '1' and db["db92-0"] == '1' and db["db93-0"] == '1'
        kv_array[KVINDEX_TYPE] = "fixed(0.1,7.5)"
      end
    end

    def get_paramtag(file, filter)
      group_list = {}
      current_group = ""
      resp = ""
      #set base table
      File.open(file){ |f|
        f.each_line{ |line|
          #skip 1st line
          line.lstrip!
          #There are all ids in Base definition, so parse only " " and "-"
          next if (!line.start_with?(';') and !line.start_with?('-'))
          #Fail safe check
          kv = line.split(';')
          if filter.length != 0
            read_flag = check_read_params_by_query_filter(kv, filter)
            next if read_flag == false
          end
          # filter the values and contents for dc06
          if kv[KVINDEX_ID] == "dc06"
            filter_for_dc06(kv)
          end
          # filter the values and contents for dc30
          if kv[KVINDEX_ID] == "dc30"
            filter_for_dc30(kv)
          end
          # check line length
          if(@kvindex_member_max == 0)
            @kvindex_member_max = kv.length
            @parameter_member_max = @kvindex_member_max - PARAMETER_KV_OFFSET
          else
            #skip line
            if(@kvindex_member_max != kv.length)
              kv = nil
              next
            end
          end
          if current_group != kv[KVINDEX_GROUP]
            current_group = kv[KVINDEX_GROUP]
            group_list.each{ |group, val|
              resp += get_xml_string(group, val, nil, filter)
            }
            group_list = {}
            GC.start
          end
          set_to_group_list(kv,group_list)
          kv = nil
        }
      }
      group_list.each{ |group, val|
        resp += get_xml_string(group, val, nil, filter)
      }
      group_list = {}
      GC.start
      return resp
    end

    #get all xml format string
    def get_xml(env)
      @parameter_count = 0
      @kvindex_member_max = 0
      @parameter_member_max = 0
      #group_list = {}
      filter = {}
      #separate query
      if(env.key?("QUERY_STRING"))
        filter = create_filter(env["QUERY_STRING"])
      end
      #create paramslist start tag, model tag, firmwareVersion tag and firmwareRevision tag
      resp = XML_ITEM_STR_DECLARATION
      resp += get_xml_head_start_tag(XML_SCHEMA_PATH, env)
      resp += get_device_information()
      #create xml root tag
      resp += get_xml_element_start_tag(XML_ITEM_STR_GROUP_ROOT, {})
      #get csv
      #group_list = create_grouplist(filter)
      resp += get_paramtag(CSV_FILE_TABLE["base"], filter)
      #group_list.each{|group, val|
        # arg1: group name, arg2: group elements, arg4: query of params_list.cgi
        #resp += get_xml_string(group, val, nil, filter)
        #GC.start
      #}
      if(@parameter_count != 0)
        resp += get_xml_element_end_tag(XML_ITEM_STR_GROUP_ROOT)
      end
      #create paramslist end tag
      resp += get_xml_head_end_tag()
      return resp
    end

    #main
    def call(env)
      result = ""
      mutex_result = VB.trylock_paramslist()
      if(mutex_result == true)
        result = get_xml(env)
        VB.unlock_paramslist()
      else
        result = "params_list.cgi is running."
      end
      GC.start
      #puts "paramslist: mutex_result #{mutex_result}\n----------\n#{result}"
      # respones
      if mutex_result
        [200, {"content-type" => "text/xml",}, ["#{result}\n"]]
      else
        [503, {"content-type" => "text/plain",}, ["#{result}\n"]]
      end
    end
  end
end
#ParamsList::ParamsList.new().call({})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0&group=Video.Stream.Stream-0.dc07-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Video.Stream.Stream-0.dc06-0&group=Time"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00.db00-0"})
#ParamsList::ParamsList.new().call({"QUERY_STRING"=>"group=Camera.db00.db00-0.db00-0"})
